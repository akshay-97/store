from setuptools import setup

setup(
    name='HyperswitchSdk',
    version='0.0.1',
    description='A backend SDK to use hyperswitch',
    license='MIT',
    packages=['HyperswitchSdk'],
    author='Michael Scott',
    keywords=['Payments']
)
